import ctypes as c
from ctypes import wintypes as w
import json
from pathlib import Path
import subprocess as sp
import sys

kernel = c.WinDLL("kernel32", use_last_error=True)

class Coord(c.Structure):
    _fields_ = [("x", c.c_short), ("y", c.c_short)]

class Rect(c.Structure):
    _fields_ = [("left", c.c_short), ("top", c.c_short), ("right", c.c_short), ("bottom", c.c_short)]

class Info(c.Structure):
    _fields_ = [("size", Coord), ("cursor", Coord), ("attribute", w.WORD), ("window", Rect), ("maxsize", Coord)]

class Font(c.Structure):
    _fields_ = [("size", w.ULONG), ("index", w.DWORD), ("cell", Coord), ("family", w.UINT), ("weight", w.UINT), ("face", w.WCHAR * 32)]

class Cell(c.Structure):
    _fields_ = [("character", w.WCHAR), ("attribute", w.WORD)]

def api(name, result, *args):
    fn = getattr(kernel, name)
    fn.restype = result
    fn.argtypes = args
    return fn

std = api("GetStdHandle", w.HANDLE, w.DWORD)
get = api("GetConsoleScreenBufferInfo", w.BOOL, w.HANDLE, c.POINTER(Info))
get_font = api("GetCurrentConsoleFontEx", w.BOOL, w.HANDLE, w.BOOL, c.POINTER(Font))
set_font = api("SetCurrentConsoleFontEx", w.BOOL, w.HANDLE, w.BOOL, c.POINTER(Font))
set_buf = api("SetConsoleScreenBufferSize", w.BOOL, w.HANDLE, Coord)
set_cursor = api("SetConsoleCursorPosition", w.BOOL, w.HANDLE, Coord)
set_window = api("SetConsoleWindowInfo", w.BOOL, w.HANDLE, w.BOOL, c.POINTER(Rect))
set_mode = api("SetConsoleMode", w.BOOL, w.HANDLE, w.DWORD)
write_text = api("WriteConsoleW", w.BOOL, w.HANDLE, w.LPCWSTR, w.DWORD, c.POINTER(w.DWORD), w.LPVOID)
write_cells = api("WriteConsoleOutputW", w.BOOL, w.HANDLE, c.POINTER(Cell), Coord, Coord, c.POINTER(Rect))
read_cells = api("ReadConsoleOutputW", w.BOOL, w.HANDLE, c.POINTER(Cell), Coord, Coord, c.POINTER(Rect))
set_cp = api("SetConsoleOutputCP", w.BOOL, w.UINT)

def check(ok, label):
    if not ok:
        raise OSError(c.get_last_error(), label)

def geometry(handle):
    info = Info()
    check(get(handle, c.byref(info)), "GetConsoleScreenBufferInfo")
    return info

def font(handle):
    f = Font()
    f.size = c.sizeof(Font)
    check(get_font(handle, False, c.byref(f)), "GetCurrentConsoleFontEx")
    return f

def use_font(handle):
    f = font(handle)
    f.cell = Coord(0, 6)
    f.face = "Lucida Console"
    f.weight = 400
    check(set_font(handle, False, c.byref(f)), "SetCurrentConsoleFontEx")

def viewport(handle, width, height, top=0):
    rect = Rect(0, top, width - 1, top + height - 1)
    check(set_window(handle, True, c.byref(rect)), "SetConsoleWindowInfo")

def emit(handle, text):
    length = w.DWORD()
    check(write_text(handle, text, len(text), c.byref(length), None) and length.value == len(text), "WriteConsoleW")

def snapshot(handle, marker):
    info = geometry(handle)
    width = info.size.x
    count = min(info.size.y, 40)
    data = (Cell * (width * count))()
    rect = Rect(0, 0, width - 1, count - 1)
    check(read_cells(handle, data, Coord(width, count), Coord(0, 0), c.byref(rect)), "ReadConsoleOutputW")
    seen = []
    for y in range(count):
        line = "".join(cell.character for cell in data[y * width:(y + 1) * width])
        x = line.find(marker)
        if x != -1:
            seen.append({"Column": x, "Row": y, "Attribute": data[y * width + x].attribute})
    f = font(handle)
    return {
        "Buffer": [width, info.size.y], "Window": [info.window.left, info.window.top, info.window.right, info.window.bottom],
        "Cursor": [info.cursor.x, info.cursor.y], "Marker": seen, "Font": [f.face, f.cell.x, f.cell.y],
    }

def measure(mode, result):
    handle = std(0xfffffff5)
    check(set_cp(437), "SetConsoleOutputCP")
    check(set_mode(handle, 7), "SetConsoleMode")
    use_font(handle)
    info = geometry(handle)
    check(set_cursor(handle, Coord(0, 0)), "initial cursor")
    viewport(handle, min(80, info.size.x), min(25, info.size.y))
    check(set_buf(handle, Coord(80, 3000)), "initial buffer dimensions")
    viewport(handle, 80, 25)
    if mode == "soft":
        emit(handle, "W" * 84)
    elif mode == "hard":
        emit(handle, "W" * 8 + "\r\n")
    marker = "STATE_READY" if mode == "positioned" else "SCREEN_PRIMARY"
    attr = 7 if mode == "positioned" else 0x1e
    frame = (Cell * (80 * 25))(*(Cell(" ", 7) for _ in range(80 * 25)))
    for i, ch in enumerate(marker):
        frame[82 + i] = Cell(ch, attr)
    if mode == "positioned":
        for x, y, text, color in ((3, 4, "\u010d\u0107\u017e\u0161\u0111", 7), (5, 6, "COLOR", 0x1e)):
            for i, ch in enumerate(text):
                frame[y * 80 + x + i] = Cell(ch, color)
    if mode == "marker-only":
        rect = Rect(2, 1, 1 + len(marker), 1)
        cells = (Cell * len(marker))(*(Cell(ch, attr) for ch in marker))
        check(write_cells(handle, cells, Coord(len(marker), 1), Coord(0, 0), c.byref(rect)), "paint marker")
    else:
        rect = Rect(0, 0, 78 if mode == "partial-frame" else 79, 24)
        check(write_cells(handle, frame, Coord(80, 25), Coord(0, 0), c.byref(rect)), "paint fixture frame")
    check(set_cursor(handle, Coord(17, 7) if mode == "positioned" else Coord(0, 8)), "fixture cursor")
    result["Initial"] = snapshot(handle, marker)
    use_font(handle)
    result["AfterFont"] = snapshot(handle, marker)
    viewport(handle, 80, 25, geometry(handle).window.top)
    result["AfterTemporaryWindow"] = snapshot(handle, marker)
    check(set_buf(handle, Coord(100, 3000)), "grow buffer")
    result["AfterBufferResize"] = snapshot(handle, marker)
    viewport(handle, 100, 30, geometry(handle).window.top)
    result["AfterFinalWindow"] = snapshot(handle, marker)

if len(sys.argv) == 3:
    mode, out = sys.argv[1:]
    result = {"Mode": mode}
    try:
        measure(mode, result)
    except Exception as error:
        result["Error"] = str(error)
    Path(out).write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    sys.exit(int("Error" in result))

path = Path(__file__).parent
start = sp.STARTUPINFO(dwFlags=sp.STARTF_USESHOWWINDOW, wShowWindow=0)
for mode in ("full-frame", "partial-frame", "marker-only"):
    result = path / f"native-{mode}.json"
    execution = sp.run([sys.executable, str(__file__), mode, str(result)],
                       creationflags=sp.CREATE_NEW_CONSOLE, startupinfo=start, timeout=15)
    saved = json.loads(result.read_text())
    print(mode, {phase: (value["Window"], value["Cursor"], value["Marker"]) for phase, value in saved.items() if isinstance(value, dict)})
    if execution.returncode:
        print(saved)
        sys.exit(execution.returncode)