import ctypes as c
from ctypes import wintypes as w
import json
from pathlib import Path
import subprocess as sp
import sys

kernel = c.WinDLL("kernel32", use_last_error=True)

class Coord(c.Structure):
    _fields_ = [("x", c.c_short), ("y", c.c_short)]

class Rect(c.Structure):
    _fields_ = [("left", c.c_short), ("top", c.c_short), ("right", c.c_short), ("bottom", c.c_short)]

class Info(c.Structure):
    _fields_ = [("size", Coord), ("cursor", Coord), ("attribute", w.WORD), ("window", Rect), ("maxsize", Coord)]

class Font(c.Structure):
    _fields_ = [("size", w.ULONG), ("index", w.DWORD), ("cell", Coord), ("family", w.UINT), ("weight", w.UINT), ("face", w.WCHAR * 32)]

class Cell(c.Structure):
    _fields_ = [("character", w.WCHAR), ("attribute", w.WORD)]

def api(name, result, *args):
    fn = getattr(kernel, name)
    fn.restype = result
    fn.argtypes = args
    return fn

std = api("GetStdHandle", w.HANDLE, w.DWORD)
get = api("GetConsoleScreenBufferInfo", w.BOOL, w.HANDLE, c.POINTER(Info))
get_font = api("GetCurrentConsoleFontEx", w.BOOL, w.HANDLE, w.BOOL, c.POINTER(Font))
set_font = api("SetCurrentConsoleFontEx", w.BOOL, w.HANDLE, w.BOOL, c.POINTER(Font))
set_buf = api("SetConsoleScreenBufferSize", w.BOOL, w.HANDLE, Coord)
set_cursor = api("SetConsoleCursorPosition", w.BOOL, w.HANDLE, Coord)
set_window = api("SetConsoleWindowInfo", w.BOOL, w.HANDLE, w.BOOL, c.POINTER(Rect))
set_mode = api("SetConsoleMode", w.BOOL, w.HANDLE, w.DWORD)
write_text = api("WriteConsoleW", w.BOOL, w.HANDLE, w.LPCWSTR, w.DWORD, c.POINTER(w.DWORD), w.LPVOID)
write_cells = api("WriteConsoleOutputW", w.BOOL, w.HANDLE, c.POINTER(Cell), Coord, Coord, c.POINTER(Rect))
read_cells = api("ReadConsoleOutputW", w.BOOL, w.HANDLE, c.POINTER(Cell), Coord, Coord, c.POINTER(Rect))
set_cp = api("SetConsoleOutputCP", w.BOOL, w.UINT)

def check(ok, label):
    if not ok:
        raise OSError(c.get_last_error(), label)

def geometry(handle):
    info = Info()
    check(get(handle, c.byref(info)), "GetConsoleScreenBufferInfo")
    return info

def font(handle):
    f = Font()
    f.size = c.sizeof(Font)
    check(get_font(handle, False, c.byref(f)), "GetCurrentConsoleFontEx")
    return f

def use_font(handle):
    f = font(handle)
    f.cell = Coord(0, 6)
    f.face = "Lucida Console"
    f.weight = 400
    check(set_font(handle, False, c.byref(f)), "SetCurrentConsoleFontEx")

def viewport(handle, width, height, top=0):
    rect = Rect(0, top, width - 1, top + height - 1)
    check(set_window(handle, True, c.byref(rect)), "SetConsoleWindowInfo")

def emit(handle, text):
    length = w.DWORD()
    check(write_text(handle, text, len(text), c.byref(length), None) and length.value == len(text), "WriteConsoleW")

def snapshot(handle, marker):
    info = geometry(handle)
    width = info.size.x
    count = min(info.size.y, 40)
    data = (Cell * (width * count))()
    rect = Rect(0, 0, width - 1, count - 1)
    check(read_cells(handle, data, Coord(width, count), Coord(0, 0), c.byref(rect)), "ReadConsoleOutputW")
    seen = []
    for y in range(count):
        line = "".join(cell.character for cell in data[y * width:(y + 1) * width])
        x = line.find(marker)
        if x != -1:
            seen.append({"Column": x, "Row": y, "Attribute": data[y * width + x].attribute})
    f = font(handle)
    return {
        "Buffer": [width, info.size.y], "Window": [info.window.left, info.window.top, info.window.right, info.window.bottom],
        "Cursor": [info.cursor.x, info.cursor.y], "Marker": seen, "Font": [f.face, f.cell.x, f.cell.y],
    }

def measure(mode, result):
    handle = std(0xfffffff5)
    check(set_cp(437), "SetConsoleOutputCP")
    check(set_mode(handle, 7), "SetConsoleMode")
    use_font(handle)
    info = geometry(handle)
    check(set_cursor(handle, Coord(0, 0)), "initial cursor")
    viewport(handle, min(80, info.size.x), min(25, info.size.y))
    check(set_buf(handle, Coord(80, 3000)), "initial buffer dimensions")
    viewport(handle, 80, 25)
    if mode == "soft":
        emit(handle, "W" * 84)
    elif mode == "hard":
        emit(handle, "W" * 8 + "\r\n")
    marker = "STATE_READY" if mode == "positioned" else "SCREEN_PRIMARY"
    attr = 7 if mode == "positioned" else 0x1e
    frame = (Cell * (80 * 25))(*(Cell(" ", 7) for _ in range(80 * 25)))
    for i, ch in enumerate(marker):
        frame[82 + i] = Cell(ch, attr)
    if mode == "positioned":
        for x, y, text, color in ((3, 4, "\u010d\u0107\u017e\u0161\u0111", 7), (5, 6, "COLOR", 0x1e)):
            for i, ch in enumerate(text):
                frame[y * 80 + x + i] = Cell(ch, color)
    rect = Rect(0, 0, 79, 24)
    check(write_cells(handle, frame, Coord(80, 25), Coord(0, 0), c.byref(rect)), "paint fixture frame")
    check(set_cursor(handle, Coord(17, 7) if mode == "positioned" else Coord(0, 8)), "fixture cursor")
    result["Initial"] = snapshot(handle, marker)
    use_font(handle)
    result["AfterFont"] = snapshot(handle, marker)
    viewport(handle, 80, 25, geometry(handle).window.top)
    result["AfterTemporaryWindow"] = snapshot(handle, marker)
    check(set_buf(handle, Coord(100, 3000)), "grow buffer")
    result["AfterBufferResize"] = snapshot(handle, marker)
    viewport(handle, 100, 30, geometry(handle).window.top)
    result["AfterFinalWindow"] = snapshot(handle, marker)

import threading
import time

user = c.WinDLL("user32", use_last_error=True)
get_window = api("GetConsoleWindow", w.HWND)
make_buffer = api("CreateConsoleScreenBuffer", w.HANDLE, w.DWORD, w.DWORD, w.LPVOID, w.DWORD, w.LPVOID)
set_active = api("SetConsoleActiveScreenBuffer", w.BOOL, w.HANDLE)
close = api("CloseHandle", w.BOOL, w.HANDLE)
window_process = user.GetWindowThreadProcessId
window_process.argtypes = [w.HWND, c.POINTER(w.DWORD)]
window_process.restype = w.DWORD
send = user.SendMessageTimeoutW
send.argtypes = [w.HWND, w.UINT, w.WPARAM, w.LPARAM, w.UINT, w.UINT, c.POINTER(c.c_size_t)]
send.restype = w.LPARAM

def run_trial(mode, receipt):
    selection = True
    primary = std(0xfffffff5)
    check(set_mode(primary, 7) and set_cp(437), "console output mode")
    use_font(primary)
    info = geometry(primary)
    check(set_cursor(primary, Coord(0, 0)), "initial cursor")
    viewport(primary, min(80, info.size.x), min(25, info.size.y))
    check(set_buf(primary, Coord(80, 3000)), "primary buffer")
    viewport(primary, 80, 25)
    alternate = make_buffer(0xc0000000, 3, None, 1, None)
    check(alternate and alternate != c.c_void_p(-1).value, "alternate buffer creation")
    check(set_buf(alternate, Coord(80, 25)), "alternate dimensions")
    viewport(alternate, 80, 25)
    check(set_active(alternate), "alternate activation")
    hwnd = get_window()
    host = w.DWORD()
    check(hwnd and window_process(hwnd, c.byref(host)), "owned console window")
    receipt["ConhostPid"] = host.value
    cells = (Cell * (80 * 25))(*(Cell(" ", 7) for _ in range(80 * 25)))
    for x, ch in enumerate("CORNER", 72):
        cells[24 * 80 + x] = Cell(ch, 0x70)
    rect = Rect(0, 0, 79, 24)
    check(write_cells(alternate, cells, Coord(80, 25), Coord(0, 0), c.byref(rect)), "alternate paint")
    check(set_cursor(alternate, Coord(7, 23)), "alternate cursor")
    stopped = threading.Event()
    counter = [0]
    writer_error = []

    def draw():
        while not stopped.is_set():
            counter[0] += 1
            label = f"FRAME {counter[0]}"
            line = (Cell * len(label))(*(Cell(ch, 0x3e) for ch in label))
            rect = Rect(3, 4, 2 + len(label), 4)
            if not write_cells(alternate, line, Coord(len(label), 1), Coord(0, 0), c.byref(rect)):
                writer_error.append(c.get_last_error())
                return
            stopped.wait(0.016)

    def toggle(on):
        if not selection:
            return
        value = c.c_size_t()
        command = (0x0112, 0xfff5, 0) if on else (0x0102, 27, 0x00010001)
        check(send(hwnd, *command, 2, 1000, c.byref(value)), "console selection transition")

    def fit(info, width, height):
        top = min(info.size.y - height, info.window.top)
        if info.window.top <= info.cursor.y <= info.window.bottom:
            if info.cursor.y < top:
                top = info.cursor.y
            elif info.cursor.y >= top + height:
                top = info.cursor.y - height + 1
        viewport(alternate, width, height, top)

    thread = threading.Thread(target=draw, daemon=True)
    thread.start()
    frozen = False
    try:
        for index in range(16):
            width, height = (100, 30) if index % 2 == 0 else (80, 25)
            receipt["Request"] = [width, height]
            receipt["Phase"] = "initial selection"
            toggle(True)
            frozen = selection
            receipt["Phase"] = "leave selection for font"
            toggle(False)
            frozen = False
            receipt["Phase"] = "font"
            use_font(alternate)
            receipt["Phase"] = "selection before temporary window"
            toggle(True)
            frozen = selection
            receipt["Phase"] = "temporary window"
            current = geometry(alternate)
            fit(current, min(width, current.size.x), min(height, current.size.y))
            receipt["Phase"] = "leave selection for buffer resize"
            toggle(False)
            frozen = False
            receipt["Phase"] = "buffer resize"
            check(set_buf(alternate, Coord(width, height)), "SetConsoleScreenBufferSize")
            shrink = index % 2 == 1
            receipt["Phase"] = "selection before final window"
            if not shrink:
                toggle(True)
                frozen = True
            receipt["Phase"] = "final window"
            fit(geometry(alternate), width, height)
            if shrink and mode == "defer-shrink":
                receipt["Phase"] = "selection after final shrink window"
                toggle(True)
                frozen = True
                receipt["Phase"] = "read geometry with selection after shrink"
                geometry(alternate)
            receipt["Phase"] = "leave final selection"
            if frozen:
                toggle(False)
                frozen = False
            receipt["Phase"] = "read geometry"
            observed = geometry(alternate)
            if list((observed.size.x, observed.size.y)) != receipt["Request"]:
                raise RuntimeError("wrong buffer geometry")
            receipt["CompletedResizes"] = index + 1
            time.sleep(0.016)
        receipt["Phase"] = "complete"
    finally:
        if frozen and get_window():
            try:
                toggle(False)
            except OSError:
                pass
        stopped.set()
        thread.join(1)
        receipt["Writes"] = counter[0]
        receipt["WriterErrors"] = writer_error
        if get_window():
            set_active(primary)
        close(alternate)

if len(sys.argv) == 3:
    mode, out = sys.argv[1:]
    receipt = {"Selection": mode, "CompletedResizes": 0}
    try:
        run_trial(mode, receipt)
    except Exception as error:
        receipt["Error"] = str(error)
    Path(out).write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
    sys.exit(int("Error" in receipt))

folder = Path(__file__).parent
start = sp.STARTUPINFO(dwFlags=sp.STARTF_USESHOWWINDOW, wShowWindow=0)
trials = []
for mode in ("skip-shrink", "defer-shrink"):
    for rep in range(1, 9):
        path = folder / f"alternate-{mode}-{rep}.json"
        execution = sp.run([sys.executable, str(__file__), mode, str(path)],
                           creationflags=sp.CREATE_NEW_CONSOLE, startupinfo=start, timeout=15)
        receipt = json.loads(path.read_text()) if path.exists() else {"Selection": mode, "Error": "trial exited without a receipt"}
        receipt["ExitCode"] = execution.returncode
        trials.append(receipt)
        print(mode, rep, receipt.get("ConhostPid"), receipt.get("CompletedResizes"), receipt.get("Phase"), receipt.get("Error"), flush=True)
(folder / "native-alternate-narrow-result.json").write_text(json.dumps(trials, indent=2) + "\n", encoding="utf-8")