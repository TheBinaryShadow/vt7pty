#include "WinTest.h"
#include "VtState.h"
#include <filesystem>
#include <fstream>
#include <iterator>

using namespace fidelity;

int wmain(int argc, wchar_t **argv) {
    if (argc != 3) return 2;
    try {
        std::ifstream stream{std::filesystem::path(argv[1]),std::ios::binary};
        std::ifstream snapshot{std::filesystem::path(argv[2]),std::ios::binary};
        auto packet = std::make_unique<Packet>();
        if (!snapshot.read(reinterpret_cast<char *>(packet.get()), sizeof(Packet)))
            throw std::runtime_error("snapshot read");
        validate(*packet);
        const std::string raw{std::istreambuf_iterator<char>{stream},{}};
        const std::string show = "\x1b[?25h";
        const auto firstShow = raw.find(show);
        if (firstShow == std::string::npos) throw std::runtime_error("first frame boundary");
        const auto split = firstShow + show.size();

        VtState terminal(80,25);
        terminal.feed(std::string_view(raw).substr(0,split));
        if (!terminal.contains(U"STATE_READY") || terminal.x() != 17 || terminal.y() != 7)
            throw std::runtime_error("unexpected initial frame");
        terminal.resize(static_cast<int>(packet->columns),static_cast<int>(packet->rows));
        terminal.feed(std::string_view(raw).substr(split));
        terminal.finish();
        printf("native origin=%u,%u cursor=%u,%u; replay cursor=%d,%d\n",
            packet->windowLeft,packet->windowTop,packet->cursorX,packet->cursorY,terminal.x(),terminal.y());

        for (unsigned offset : {0u, packet->windowTop}) {
            unsigned text=0, attributes=0, sample=0;
            for (unsigned y=0; y+offset<packet->rows; ++y) {
                for (unsigned x=0; x<packet->columns; ++x) {
                    const auto &n = packet->cells[y*packet->columns+x];
                    const auto &v = terminal.at(static_cast<int>(x),static_cast<int>(y+offset));
                    if (v.text != std::u32string(1,static_cast<char32_t>(n.Char.UnicodeChar)) || v.continuation) ++text;
                    if (v.attributes != (n.Attributes & 0x80ff)) ++attributes;
                    ++sample;
                }
            }
            printf("row offset=%u cells=%u text differences=%u attribute differences=%u cursor relative y=%d\n",
                offset,sample,text,attributes,terminal.y()-static_cast<int>(offset));
        }
        return 0;
    } catch (const std::exception &error) {
        fprintf(stderr,"%s\n",error.what());
        return 1;
    }
}